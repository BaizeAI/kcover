#!/bin/bash
set -e

CURDIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)

if command -v apt >/dev/null; then
    dpkg -i --force-overwrite ${CURDIR}/mxrdma_*.deb
elif command -v yum >/dev/null; then
    rpm -ivh --force ${CURDIR}/mxrdma_*.rpm
else
    echo "apt and yum are not found."
    exit 1
fi
